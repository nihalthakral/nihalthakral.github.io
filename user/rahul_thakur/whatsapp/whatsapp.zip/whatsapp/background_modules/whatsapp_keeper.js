// ============================================================
//  BACKGROUND MODULE — WhatsApp Keeper
//  Kaam: Agar WhatsApp Web band ho to automatically khol do.
//  Original logic bilkul same hai, sirf module mein rakha hai.
// ============================================================
//
//  ✅ NEW: Universal Error Handling
//  - Koi bhi error aaye → chrome.storage.local mein save hoga
//  - Extension kaam karna band kar dega
//  - Har 10 seconds mein retry hoga
//  - "No Error" detect hote hi extension dobara chal jayega
//
// ============================================================

import { isTrialExpired } from '../core/trial.js';

// ============================================================
//  ERROR STATE MANAGEMENT
// ============================================================

let isInErrorState = false;   // in-memory fast check ke liye
let retryTimer    = null;     // 10-second retry interval

// Koi bhi error aaye → yahan report karo
// background.js bhi ise import karke global errors report karta hai
export function reportError(message) {
  const msg = String(message || 'Unknown Error');
  isInErrorState = true;
  chrome.storage.local.set({ extensionError: msg });

  // Retry timer shuru karo (agar pehle se nahi chal raha)
  if (!retryTimer) {
    retryTimer = setInterval(attemptRecovery, 10000);
  }
}

// Har 10 seconds mein recovery check karo
function attemptRecovery() {
  try {
    // Chrome API ko ek simple query bhejo — agar kaam kare to extension theek hai
    chrome.tabs.query({}, () => {
      if (chrome.runtime.lastError) {
        // Abhi bhi error → retry jari rahega
        reportError(chrome.runtime.lastError.message);
        return;
      }

      // ✅ No Error — state clear karo, normal operation resume karo
      isInErrorState = false;
      chrome.storage.local.set({ extensionError: null });
      clearInterval(retryTimer);
      retryTimer = null;

      // Turant ek check karo — normal mode resume
      checkAndOpenWhatsApp(false);
    });
  } catch (err) {
    reportError(err.message || String(err));
  }
}

// Service Worker restart hone par bhi storage se error state restore karo
// (Service Workers restart hote rehte hain — in-memory state reset ho jaati hai)
function restoreErrorStateFromStorage() {
  chrome.storage.local.get(['extensionError'], (result) => {
    if (chrome.runtime.lastError) return;
    if (result.extensionError) {
      isInErrorState = true;
      if (!retryTimer) {
        retryTimer = setInterval(attemptRecovery, 10000);
      }
    }
  });
}

// ============================================================
//  BUG FIX — Chrome band hone par WhatsApp nahi kholna chahiye
//
//  Purani problem:
//    tabs.onRemoved do cases mein fire hota tha:
//      1. User ne sirf WhatsApp tab band ki → WhatsApp dobara kholo ✅
//      2. User ne Chrome band kiya → saare tabs remove ho rahe hain ❌
//    Dono cases mein windows.length === 0 aata tha aur windows.create()
//    call ho jaata tha — Chrome close hi nahi hota tha!
//
//  Real Fix:
//    Naya window (windows.create) SIRF onStartup pe banao.
//    tabs.onRemoved se trigger hone par, sirf tab banao —
//    aur woh bhi tabhi jab koi window already exist karti ho.
//    Agar windows.length === 0 aur onStartup nahi hai →
//    Chrome band ho raha hai, kuch mat karo. ✅
// ============================================================

function sendTrackingPing() {
  var name = "Rahul_Thakur_Whatsapp_Extension";
  fetch(
    "https://visitor-tracker.nihalthakral-trader.workers.dev/track?name="
    + encodeURIComponent(name) + "&t=" + Date.now()
  ).catch(() => {}); // silently ignore any network errors
}

// isStartup = true sirf tab jab chrome.runtime.onStartup ne call kiya ho
function checkAndOpenWhatsApp(isStartup = false) {
  // Trial khatam ho gayi hai to chup chap band ho jao
  if (isTrialExpired()) return;

  // Error state mein kaam band — retry timer sambhaal lega
  if (isInErrorState) return;

  // Pehle storage se enabled state check karo
  chrome.storage.local.get(['enabled'], (result) => {
    if (chrome.runtime.lastError) {
      reportError(chrome.runtime.lastError.message);
      return;
    }

    const isEnabled = result.enabled !== false; // default: ON
    if (!isEnabled) return; // OFF hai to kuch mat karo

    chrome.tabs.query({}, (tabs) => {
      if (chrome.runtime.lastError) {
        reportError(chrome.runtime.lastError.message);
        return;
      }

      const isWhatsAppOpen = tabs.some(tab =>
        tab.url && tab.url.startsWith("https://web.whatsapp.com/")
      );

      if (!isWhatsAppOpen) {
        chrome.windows.getAll({}, (windows) => {
          if (chrome.runtime.lastError) {
            reportError(chrome.runtime.lastError.message);
            return;
          }

          if (windows.length === 0) {
            // Koi window nahi — do situations ho sakti hain:
            //   a) Chrome abhi fresh start hua hai (isStartup = true) → window banao ✅
            //   b) Chrome band ho raha hai (isStartup = false)        → kuch mat karo ✅
            if (isStartup) {
              chrome.windows.create({ url: "https://web.whatsapp.com/" }, () => {
                if (chrome.runtime.lastError) { reportError(chrome.runtime.lastError.message); return; }
                sendTrackingPing();
              });
            }
          } else {
            // Windows exist karti hain — normal tab banao
            chrome.tabs.create({ url: "https://web.whatsapp.com/" }, () => {
              if (chrome.runtime.lastError) { reportError(chrome.runtime.lastError.message); return; }
              sendTrackingPing();
            });
          }
        });
      }
    });
  });
}

// ---- Debounce — 500ms mein baar baar call aaye toh sirf ek hi chalega ----
let openTimer = null;
function debouncedCheck(isStartup = false) {
  if (openTimer) clearTimeout(openTimer);
  openTimer = setTimeout(() => {
    openTimer = null;
    try {
      checkAndOpenWhatsApp(isStartup);
    } catch (err) {
      reportError(err.message || String(err));
    }
  }, 500);
}

export function init() {
  // Service worker restart ke baad storage se error state restore karo
  restoreErrorStateFromStorage();

  // Jab bhi koi bhi tab BAND ho — check karo
  // isStartup = false: tab close hua, Chrome band nahi hua
  chrome.tabs.onRemoved.addListener(() => {
    debouncedCheck(false);
  });

  // Jab bhi koi tab ka URL change ho (user WhatsApp se navigate kar jaye)
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.url) {
      debouncedCheck(false);
    }
  });

  // Jab Chrome band hoke DOBARA khule — isStartup = true
  // Yahi ek jagah hai jahan windows.length === 0 par bhi window banana sahi hai
  chrome.runtime.onStartup.addListener(() => {
    debouncedCheck(true);
  });

  // Extension start hone par bhi ek baar check karo
  debouncedCheck(false);
}
