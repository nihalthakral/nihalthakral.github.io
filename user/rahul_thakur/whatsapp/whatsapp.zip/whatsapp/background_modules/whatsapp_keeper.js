// ============================================================
//  BACKGROUND MODULE — WhatsApp Keeper
//  Kaam: Agar WhatsApp Web band ho to automatically khol do.
//  Original logic bilkul same hai, sirf module mein rakha hai.
// ============================================================

import { isTrialExpired } from '../core/trial.js';

function checkAndOpenWhatsApp() {
  // Trial khatam ho gayi hai to chup chap band ho jao
  if (isTrialExpired()) return;

  // Pehle storage se enabled state check karo
  chrome.storage.local.get(['enabled'], (result) => {
    const isEnabled = result.enabled !== false; // default: ON

    if (!isEnabled) return; // OFF hai to kuch mat karo

    chrome.tabs.query({}, (tabs) => {
      const isWhatsAppOpen = tabs.some(tab =>
        tab.url && tab.url.startsWith("https://web.whatsapp.com/")
      );

      if (!isWhatsAppOpen) {
        // Pehle check karo koi window hai ya nahi (Chrome startup case)
        chrome.windows.getAll({}, (windows) => {
          if (windows.length === 0) {
            // Koi window nahi — naya window banao WhatsApp ke saath
            chrome.windows.create({ url: "https://web.whatsapp.com/" });
          } else {
            // Window exist karti hai — normal tab banao
            chrome.tabs.create({ url: "https://web.whatsapp.com/" });
          }
        });
      }
    });
  });
}

export function init() {
  // Jab bhi koi bhi tab BAND ho — turant check karo (instant!)
  // Service worker bhi khud jagega is event se
  chrome.tabs.onRemoved.addListener(() => {
    checkAndOpenWhatsApp();
  });

  // Jab bhi koi tab ka URL change ho (user WhatsApp se navigate kar jaye)
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.url) {
      checkAndOpenWhatsApp();
    }
  });

  // Jab Chrome band hoke DOBARA khule — turant WhatsApp kholo
  chrome.runtime.onStartup.addListener(() => {
    checkAndOpenWhatsApp();
  });

  // Extension start hone par bhi ek baar turant check karo
  checkAndOpenWhatsApp();
}
