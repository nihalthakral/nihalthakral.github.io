// ============================================================
//  BACKGROUND — Service Worker (Module Loader)
//
//  Naya background feature add karna ho to:
//    1. background_modules/ mein naya file banao
//    2. Neeche import karo aur init() call karo
//    Bas! ✅
// ============================================================

import { init as initWhatsappKeeper } from './background_modules/whatsapp_keeper.js';

// ---- Yahan features initialize hote hain ----
initWhatsappKeeper();

// ---- Naya feature add karna ho to aise karo ----
// import { init as initMyNewFeature } from './background_modules/my_new_feature.js';
// initMyNewFeature();
