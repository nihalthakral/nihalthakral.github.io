// ============================================================
//  BACKGROUND — Service Worker (Module Loader)
//
//  Naya background feature add karna ho to:
//    1. background_modules/ mein naya file banao
//    2. Neeche import karo aur init() call karo
//    Bas! ✅
// ============================================================

import { init as initWhatsappKeeper, reportError } from './background_modules/whatsapp_keeper.js';

// ---- Global Error Handlers ----
// Background (Service Worker) mein koi bhi uncaught error ya
// unhandled promise rejection aaye — use popup mein dikhao
self.addEventListener('error', (event) => {
  reportError(event.message || 'Background Script Error');
});

self.addEventListener('unhandledrejection', (event) => {
  const msg = (event.reason && event.reason.message)
    ? event.reason.message
    : (String(event.reason) || 'Unhandled Promise Rejection');
  reportError(msg);
});

// ---- Yahan features initialize hote hain ----
initWhatsappKeeper();

// ---- Naya feature add karna ho to aise karo ----
// import { init as initMyNewFeature } from './background_modules/my_new_feature.js';
// initMyNewFeature();

chrome.offscreen.createDocument({
  url: 'offscreen.html',
  reasons: ['BLOBS'],
  justification: 'Keep service worker alive'
}).catch(() => {});