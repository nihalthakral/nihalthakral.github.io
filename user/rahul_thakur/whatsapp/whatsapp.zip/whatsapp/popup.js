// ============================================================
//  POPUP — Main Script (Module Loader)
//
//  Naya popup feature add karna ho to:
//    1. popup_modules/ mein naya file banao
//    2. Neeche import karo aur init() call karo
//    Bas! ✅
// ============================================================

import { init as initTrialUI }        from './popup_modules/trial_ui.js';
import { init as initWhatsappToggle } from './popup_modules/whatsapp_toggle.js';
import { init as initErrorDisplay }   from './popup_modules/error_display.js';

// ---- Popup level global errors bhi catch karo ----
// (Popup ek normal webpage hai — window.onerror yahan kaam karta hai)
window.addEventListener('error', (event) => {
  chrome.storage.local.set({
    extensionError: 'Popup Error: ' + (event.message || 'Unknown')
  });
});
window.addEventListener('unhandledrejection', (event) => {
  const msg = (event.reason && event.reason.message)
    ? event.reason.message
    : (String(event.reason) || 'Unknown');
  chrome.storage.local.set({ extensionError: 'Popup Error: ' + msg });
});

// ---- Yahan features initialize hote hain ----
initTrialUI();
initWhatsappToggle();
initErrorDisplay();

// ---- Naya popup feature add karna ho to aise karo ----
// import { init as initMyNewFeature } from './popup_modules/my_new_feature.js';
// initMyNewFeature();
