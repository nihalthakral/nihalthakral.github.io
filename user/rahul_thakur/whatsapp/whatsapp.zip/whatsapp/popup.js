// ============================================================
//  POPUP — Main Script (Module Loader)
//
//  Naya popup feature add karna ho to:
//    1. popup_modules/ mein naya file banao
//    2. Neeche import karo aur init() call karo
//    Bas! ✅
// ============================================================

import { init as initTrialUI }        from './popup_modules/trial_ui.js';
import { init as initWhatsappToggle } from './popup_modules/whatsapp_toggle.js';

// ---- Yahan features initialize hote hain ----
initTrialUI();
initWhatsappToggle();

// ---- Naya popup feature add karna ho to aise karo ----
// import { init as initMyNewFeature } from './popup_modules/my_new_feature.js';
// initMyNewFeature();
