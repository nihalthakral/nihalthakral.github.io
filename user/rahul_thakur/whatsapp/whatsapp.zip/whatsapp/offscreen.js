// ============================================================
//  OFFSCREEN SCRIPT — Timer
//  Kaam: Har 5 seconds mein background service worker ko
//  message bhejo. Service worker so bhi jaaye to yeh
//  page alive rehta hai aur usse wapas jagata hai.
// ============================================================

setInterval(() => {
  chrome.runtime.sendMessage({ type: 'whatsappKeeperTick' }).catch(() => {
    // Service worker restart ho raha hai — koi baat nahi, agla tick aayega
  });
}, 5000);
