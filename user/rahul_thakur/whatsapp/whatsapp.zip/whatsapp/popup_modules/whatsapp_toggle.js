// ============================================================
//  POPUP MODULE — WhatsApp Toggle (ON/OFF)
//  Kaam: Popup mein toggle switch ka kaam karna.
//  Original logic bilkul same hai.
// ============================================================

import { isTrialExpired } from '../core/trial.js';

export function init() {
  if (isTrialExpired()) return; // Trial khatam hai to toggle kaam nahi karega

  const toggle = document.getElementById('toggle');

  // State load karo storage se
  chrome.storage.local.get(['enabled'], (result) => {
    const isOn = result.enabled !== false; // default: ON
    toggle.checked = isOn;
  });

  // Toggle change hone par storage update karo
  toggle.addEventListener('change', () => {
    const isOn = toggle.checked;
    chrome.storage.local.set({ enabled: isOn });
  });
}
