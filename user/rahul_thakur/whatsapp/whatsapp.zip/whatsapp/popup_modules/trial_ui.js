// ============================================================
//  POPUP MODULE — Trial Expired UI
//  Kaam: Trial khatam hone par expired screen dikhao.
//  Original logic bilkul same hai.
// ============================================================

import { isTrialExpired } from '../core/trial.js';

export function init() {
  if (!isTrialExpired()) return; // Trial active hai to kuch mat karo

  // Trial khatam — expired UI dikhao, normal UI chhupao
  document.getElementById('normal-ui').style.display = 'none';
  document.getElementById('trial-expired').style.display = 'block';

  // Contact button — seedha Gmail compose kholega
  document.getElementById('contact-btn').addEventListener('click', () => {
    const email = 'nihalthakral.trader@gmail.com';
    const subject = encodeURIComponent('Always Open WhatsApp - Extension Inquiry');
    chrome.tabs.create({ url: `https://mail.google.com/mail/?view=cm&to=${email}&su=${subject}` });
  });
}
