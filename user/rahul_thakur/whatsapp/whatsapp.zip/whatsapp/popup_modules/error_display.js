// ============================================================
//  POPUP MODULE — Error Display
//  Kaam: chrome.storage.local se error padho aur popup mein dikhao.
//
//  - Error hai  → red badge mein message dikhao
//  - Error nahi → green badge mein "No Error" dikhao
//  - Har 3 seconds mein refresh hota hai (retry ke baad auto-update)
// ============================================================

export function init() {
  const statusEl = document.getElementById('error-status');
  if (!statusEl) return;

  function refresh() {
    chrome.storage.local.get(['extensionError'], (result) => {
      if (chrome.runtime.lastError) return; // storage read fail — silently skip

      const err = result.extensionError;
      if (err) {
        // Bohot lamba message ho to truncate karo
        const display = err.length > 110 ? err.substring(0, 110) + '…' : err;
        statusEl.textContent = '⚠ ' + display;
        statusEl.className = 'error-badge has-error';
      } else {
        statusEl.textContent = '✓ No Error';
        statusEl.className = 'error-badge no-error';
      }
    });
  }

  refresh();                   // Popup khulte hi turant dikhao
  setInterval(refresh, 3000);  // Har 3 seconds mein update karo
}
