/*
  ERROR CODES (is file ke):
  03 → Settings button click — chrome.tabs.create ya runtime.getURL fail hua
  30 → Open Gmail button    — chrome.storage.local.get fail (account_number)
  31 → Open Gmail button    — chrome.tabs.create fail
*/

document.addEventListener("DOMContentLoaded", async function () {

  // ── Trial Check ──────────────────────────────────────────────
  // _v() gate.js se aata hai — false = trial khatam
  if (typeof _v === "function" && !_v()) {

    // Normal UI chupao
    const normalView = document.getElementById("normal-view");
    if (normalView) normalView.style.display = "none";

    // Expired UI dikhao
    const expiredView = document.getElementById("expired-view");
    if (expiredView) expiredView.style.display = "flex";

    // Contact button — click par client ka Gmail khulega, To field filled
    const contactBtn = document.getElementById("btn-contact");
    if (contactBtn) {
      contactBtn.addEventListener("click", function () {
        try {
          chrome.tabs.create({
            url: "https://mail.google.com/mail/?view=cm&fs=1&to=nihalthakral.trader@gmail.com"
          });
        } catch (_) {}
      });
    }

    return; // Baaki kuch nahi chalega
  }

  // ── Normal Flow — Settings Button ────────────────────────────

  const settingsBtn = document.getElementById("openSettings");
  if (settingsBtn) {
    settingsBtn.addEventListener("click", async () => {
      try {
        const url = chrome.runtime.getURL("settings.html");
        await chrome.tabs.create({ url });
      } catch (err) {
        alert("Error Code : 03\n\n" + err.message);
      }
    });
  }

  // ── Normal Flow — Open Gmail Button ──────────────────────────

  const gmailBtn = document.getElementById("gmail");
  if (!gmailBtn) return;

  gmailBtn.addEventListener("click", async function () {
    // account_number storage se padho
    let accountNumber;
    try {
      const r = await chrome.storage.local.get("account_number");
      accountNumber = r["account_number"];
    } catch (err) {
      alert("Error Code : 30\n\n" + err.message);
      return;
    }

    // account_number mila aur valid hai → direct URL banao
    // nahi mila (setup nahi hua) → generic Gmail fallback
    const url =
      accountNumber !== undefined
        ? `https://mail.google.com/mail/u/${accountNumber}/`
        : "https://mail.google.com/";

    try {
      chrome.tabs.create({ url });
    } catch (err) {
      alert("Error Code : 31\n\n" + err.message);
    }
  });
});
