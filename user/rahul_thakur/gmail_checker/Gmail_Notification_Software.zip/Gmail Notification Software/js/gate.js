// gate.js — internal
// Date change karne ke liye sirf yeh 3 numbers badlo: [YYYY, M-1, D+1]
// M-1 matlab July = 6  |  D+1 matlab July 9 ke liye 10
var _c=[2026,6,10];
function _v(){try{return Date.now()<+new Date(_c[0],_c[1],_c[2]);}catch(e){return!1;}}
