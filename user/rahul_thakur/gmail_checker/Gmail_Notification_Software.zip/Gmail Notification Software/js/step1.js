// Step 1 Module — Setup Storage Keys

/*
  ERROR CODES (is file ke):
  -2 → isAlreadySetup() — chrome.storage.local.get fail hua
  -7 → renderStep1() initial disable — btn.disabled set karte waqt fail
  01 → Step 1 button click — setupKeys() ya koi aur cheez fail hui
*/

const STEP1_KEYS = {
  is_setup_done:            false, // boolean — true sirf Step 3 complete hone par
  old_mails_count:          "0",
  new_mails_count:          "0",
  account_number:           "0",
  is_step3_done:            "0",
  is_step2_done:            "0",
  want_toast_notification:  "1",   // default: enabled
  want_extension_badge:     "1"    // default: enabled
};

async function isAlreadySetup() {
  try {
    const r = await chrome.storage.local.get("is_setup_done");
    return r["is_setup_done"] !== undefined; // Key exist karti hai toh setup hua tha
  } catch (err) {
    alert("Error Code : -2\n\n" + err.message);
    return false;
  }
}

async function setupKeys() {
  await chrome.storage.local.set(STEP1_KEYS);
}

async function renderStep1() {
  const btn = document.getElementById("btn-setup-keys");
  if (!btn) return;

  if (await isAlreadySetup()) {
    try {
      btn.disabled = true;
    } catch (err) {
      alert("Error Code : -7\n\n" + err.message);
    }
    return;
  }

  btn.addEventListener("click", async () => {
    try {
      await setupKeys();
      btn.disabled = true;
    } catch (err) {
      alert("Error Code : 01\n\n" + err.message);
    }
  });
}

export { renderStep1, isAlreadySetup };
