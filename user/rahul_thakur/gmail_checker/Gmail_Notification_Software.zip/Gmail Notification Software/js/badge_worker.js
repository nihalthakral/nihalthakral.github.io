// Badge Worker — Parallel Badge Loop
// Yeh loop badge_worker.js background.js ke saath parallel chalti hai.
// Settings page open karne ki zarurat NAHI hai — yeh SW ke andar chalta hai.

/*
  ERROR CODES (is file ke):
  22 → badge_worker.js — storage read fail
                         (old_mails_count / new_mails_count /
                          want_extension_badge / want_toast_notification)
  23 → badge_worker.js — chrome.action.setBadgeText fail (badge lagane waqt)
  24 → badge_worker.js — chrome.action.setBadgeBackgroundColor fail
  25 → badge_worker.js — chrome.action.setBadgeText fail (badge hatane waqt)
*/

const BADGE_CHECK_INTERVAL_MS = 3000;
const BADGE_EMOJI              = "\uD83D\uDC40"; // 👀

// SW restart hone par yeh teeno reset ho jaate hain
let badgeLoopRunning    = false;
let badgeCurrentlyShown = false;
let toastAlreadySent    = false;

// ── Helpers ───────────────────────────────────────────────────

function waitBadge(ms) {
  return new Promise(res => setTimeout(res, ms));
}

async function setBadgeError(code, msg) {
  try {
    await chrome.storage.local.set({
      badge_last_error_code: String(code),
      badge_last_error_msg:  `[${code}] ${msg}`
    });
  } catch (_) {
    console.error(`[BADGE ERR ${code}] ${msg}`);
  }
}

async function clearBadgeError() {
  try {
    await chrome.storage.local.set({
      badge_last_error_code: "",
      badge_last_error_msg:  ""
    });
  } catch (_) {}
}

// ── Badge Loop ────────────────────────────────────────────────
// Har 3 seconds mein check karta hai.
//
// Badge logic:
//   old_mails_count < new_mails_count  AND  want_extension_badge === "1"
//   → Badge dikhao (sirf ek baar)
//   → Koi bhi condition fail → badge hatao
//
// Toast logic (badge ke saath coupled — same trigger event):
//   old_mails_count < new_mails_count  AND  want_toast_notification === "1"
//   → Toast bhejo (sirf ek baar)
//   → Condition reset hone par toastAlreadySent reset hoga

async function badgeLoop() {
  badgeLoopRunning = true;

  while (true) {

    // ── Trial check — expired hone par badge clear karo aur wait karo ──
    if (!_v()) {
      // Agar badge abhi dikh raha tha toh hatao
      if (badgeCurrentlyShown) {
        try { await chrome.action.setBadgeText({ text: "" }); } catch (_) {}
        badgeCurrentlyShown = false;
      }
      toastAlreadySent = false; // Toast state reset
      await waitBadge(60000);
      continue;
    }

    // ════════════════════════════════════════════════════════════
    // PHASE 1 — Storage se chaar values padho
    // ════════════════════════════════════════════════════════════

    let oldCount, newCount, wantBadge, wantToast;
    try {
      const r = await chrome.storage.local.get([
        "old_mails_count",
        "new_mails_count",
        "want_extension_badge",
        "want_toast_notification"
      ]);
      oldCount  = r["old_mails_count"];
      newCount  = r["new_mails_count"];
      wantBadge = r["want_extension_badge"];
      wantToast = r["want_toast_notification"];
    } catch (err) {
      await setBadgeError(22, "Storage read fail: " + err.message);
      await waitBadge(BADGE_CHECK_INTERVAL_MS);
      continue;
    }

    // ════════════════════════════════════════════════════════════
    // PHASE 2 — Conditions evaluate karo
    // ════════════════════════════════════════════════════════════

    const oldNum = Number(oldCount);
    const newNum = Number(newCount);

    // Base condition — naya mail aaya hai
    const isNewMail = (
      !isNaN(oldNum) &&
      !isNaN(newNum) &&
      oldNum < newNum
    );

    // Badge aur Toast dono independently controlled hain
    const shouldShowBadge = isNewMail && String(wantBadge) === "1";
    const shouldShowToast = isNewMail && String(wantToast) === "1";

    // ════════════════════════════════════════════════════════════
    // PHASE 3a — Badge set / clear karo
    // ════════════════════════════════════════════════════════════

    if (shouldShowBadge) {

      // Badge lagana hai — lekin sirf agar abhi nahi laga hua
      if (!badgeCurrentlyShown) {

        // Badge text set karo
        try {
          await chrome.action.setBadgeText({ text: BADGE_EMOJI });
        } catch (err) {
          await setBadgeError(23, "setBadgeText fail: " + err.message);
          await waitBadge(BADGE_CHECK_INTERVAL_MS);
          continue;
        }

        // Badge background color set karo
        try {
          await chrome.action.setBadgeBackgroundColor({ color: "#E8520A" });
        } catch (err) {
          await setBadgeError(24, "setBadgeBackgroundColor fail: " + err.message);
          await waitBadge(BADGE_CHECK_INTERVAL_MS);
          continue;
        }

        badgeCurrentlyShown = true;
        await clearBadgeError();
      }
      // Agar already laga hua hai — kuch mat karo

    } else {

      // Badge nahi hona chahiye — agar laga hua hai toh hatao
      if (badgeCurrentlyShown) {

        try {
          await chrome.action.setBadgeText({ text: "" });
        } catch (err) {
          await setBadgeError(25, "setBadgeText clear fail: " + err.message);
          await waitBadge(BADGE_CHECK_INTERVAL_MS);
          continue;
        }

        badgeCurrentlyShown = false;
        await clearBadgeError();
      }
      // Agar pehle se nahi laga hua — kuch mat karo

    }

    // ════════════════════════════════════════════════════════════
    // PHASE 3b — Toast send / reset karo
    // ════════════════════════════════════════════════════════════

    if (shouldShowToast) {

      // Toast bhejo — lekin sirf agar is condition cycle mein nahi bheja
      if (!toastAlreadySent) {
        sendToastNotification(); // toast_worker.js — fire-and-forget
        toastAlreadySent = true;
      }
      // Agar already bheja hua hai — kuch mat karo

    } else {

      // Condition clear ho gayi — flag reset karo
      // Agli baar new mail aane par toast dobara fire hoga
      if (toastAlreadySent) {
        toastAlreadySent = false;
      }

    }

    await waitBadge(BADGE_CHECK_INTERVAL_MS);
  }
}
