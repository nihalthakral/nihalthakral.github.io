// Toast Worker — Chrome Notification + Audio Playback
// Badge Worker se call hota hai jab new mail condition fire hoti hai
// (old_mails_count < new_mails_count  AND  want_toast_notification === "1")

/*
  ERROR CODES (is file ke):
  32 → toast_worker.js — chrome.notifications.create fail
  33 → toast_worker.js — notifications.onClicked: chrome.tabs.create fail
  34 → toast_worker.js — offscreen document create ya audio play fail
  35 → toast_worker.js — CLOSE_OFFSCREEN_DOCUMENT: chrome.offscreen.closeDocument fail
*/

// ── Storage Error Helpers ─────────────────────────────────────

async function setToastError(code, msg) {
  try {
    await chrome.storage.local.set({
      toast_last_error_code: String(code),
      toast_last_error_msg:  `[${code}] ${msg}`
    });
  } catch (_) {
    console.error(`[TOAST ERR ${code}] ${msg}`);
  }
}

async function clearToastError() {
  try {
    await chrome.storage.local.set({
      toast_last_error_code: "",
      toast_last_error_msg:  ""
    });
  } catch (_) {}
}

// ── Offscreen Audio ───────────────────────────────────────────
// MV3 Service Worker mein Audio() nahi chalta — offscreen document use karo
// Chrome 116+ required (offscreen API)

const OFFSCREEN_URL = chrome.runtime.getURL("offscreen.html");

async function playNotificationAudio() {
  try {

    // Existing offscreen document check karo
    let hasDoc = false;
    try {
      const contexts = await chrome.runtime.getContexts({
        contextTypes: ["OFFSCREEN_DOCUMENT"],
        documentUrls: [OFFSCREEN_URL]
      });
      hasDoc = contexts.length > 0;
    } catch (_) {
      // getContexts unavailable (older Chrome) — banane ki koshish karo
      hasDoc = false;
    }

    if (!hasDoc) {
      await chrome.offscreen.createDocument({
        url:           OFFSCREEN_URL,
        reasons:       ["AUDIO_PLAYBACK"],
        justification: "Gmail notification sound playback"
      });
    }

    // Offscreen document ko message bhejo audio play karne ke liye
    // .catch() — agar koi listener nahi toh silent fail
    chrome.runtime.sendMessage({ type: "PLAY_NOTIFICATION_SOUND" }).catch(() => {});

  } catch (err) {
    await setToastError(34, "offscreen/audio fail: " + err.message);
  }
}

// ── Offscreen Document Close Handler ─────────────────────────
// offscreen.js chrome.offscreen.closeDocument() seedha nahi call kar sakta —
// woh API sirf Service Worker mein available hai, offscreen document mein nahi.
// Isliye offscreen.js CLOSE_OFFSCREEN_DOCUMENT message bhejta hai
// aur hum yahan Service Worker context mein closeDocument() call karte hain.

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type !== "CLOSE_OFFSCREEN_DOCUMENT") return;

  chrome.offscreen.closeDocument().catch(async (err) => {
    await setToastError(35, "closeDocument fail: " + err.message);
  });
});

// ── Send Toast Notification ───────────────────────────────────
// Badge Worker yeh function call karta hai — fire-and-forget (no await needed)

async function sendToastNotification() {

  // Chrome notification create karo
  try {
    await chrome.notifications.create("gmail-new-mail-" + Date.now(), {
      type:     "basic",
      iconUrl:  chrome.runtime.getURL("icons/icon.png"),
      title:    "\uD83D\uDCEC New Mail - Open Gmail", 
      message:  "Made by Nihal Thakral 🎁",
      priority: 2,
      silent:   true  // System sound band — custom audio.mp3 bajao neeche
    });
    await clearToastError();
  } catch (err) {
    await setToastError(32, "notifications.create fail: " + err.message);
    return; // Notification nahi bani — audio bhi mat bajao
  }

  // Notification ban gayi — audio bajao
  await playNotificationAudio();
}

// ── Notification Click Handler ────────────────────────────────
// Sirf ek baar register hota hai — toast_worker.js load hote waqt
// SW restart par dobara register hoga

chrome.notifications.onClicked.addListener(async (notifId) => {
  // Sirf hamare notifications handle karo
  if (!notifId.startsWith("gmail-new-mail-")) return;

  // Notification dismiss karo
  chrome.notifications.clear(notifId).catch(() => {});

  // account_number padho — correct Gmail tab kholne ke liye
  let accountNumber;
  try {
    const r = await chrome.storage.local.get("account_number");
    accountNumber = r["account_number"];
  } catch (_) {
    accountNumber = undefined;
  }

  const url =
    accountNumber !== undefined
      ? `https://mail.google.com/mail/u/${accountNumber}/`
      : "https://mail.google.com/";

  try {
    await chrome.tabs.create({ url });
  } catch (err) {
    await setToastError(33, "tabs.create fail: " + err.message);
  }
});
