// Reset Module — Clear all keys and reset steps

/*
  ERROR CODES (is file ke):
  0 → Reset button — chrome.storage.local.remove ya reload fail
*/

const RESET_KEYS = [
  "is_setup_done",
  "old_mails_count",
  "new_mails_count",
  "account_number",
  "is_step2_done",
  "is_step3_done",
  "want_toast_notification",
  "want_extension_badge",
  "bg_last_error_code",
  "bg_last_error_msg",
  "badge_last_error_code",
  "badge_last_error_msg",
  "toast_last_error_code",
  "toast_last_error_msg",
  "loading_last_error_code",
  "loading_last_error_msg"
];

async function resetAllSteps() {
  try {
    await chrome.storage.local.remove(RESET_KEYS);
    location.reload();
  } catch (err) {
    alert("Error Code : 0\n\n" + err.message);
  }
}

function renderResetButton() {
  const btn = document.getElementById("btn-reset-all");
  if (!btn) return;

  btn.addEventListener("click", () => {
    resetAllSteps();
  });
}

export { renderResetButton };
