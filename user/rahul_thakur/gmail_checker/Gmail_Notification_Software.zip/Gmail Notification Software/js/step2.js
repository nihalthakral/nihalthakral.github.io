// Step 2 Module — Set Google Account Index + Notification Preferences

/*
  ERROR CODES (is file ke):
  -3 → isStep1Done() — chrome.storage.local.get fail hua
  -4 → isStep2Done() — chrome.storage.local.get fail hua
  02 → Step 2 save button click — koi bhi operation fail hua
       (account_number, checkbox values, ya is_step2_done save karte waqt)
*/

const STEP2_CHECKBOXES = [
  { id: "chk-toast", storageKey: "want_toast_notification" },
  { id: "chk-badge", storageKey: "want_extension_badge"    },
];

async function isStep1Done() {
  try {
    const r = await chrome.storage.local.get("is_setup_done");
    return r["is_setup_done"] !== undefined; // Key exist karti hai toh step 1 hua tha
  } catch (err) {
    alert("Error Code : -3\n\n" + err.message);
    return false;
  }
}

async function isStep2Done() {
  try {
    const r = await chrome.storage.local.get("is_step2_done");
    return r["is_step2_done"] === "1";
  } catch (err) {
    alert("Error Code : -4\n\n" + err.message);
    return false;
  }
}

async function renderStep2() {
  const btn   = document.getElementById("btn-save-account");
  const input = document.getElementById("input-account-number");
  if (!btn || !input) return;

  // Storage se checkbox ki current values padho aur set karo.
  // Yeh page refresh ke baad correct tick state restore karta hai.
  // Agar storage mein value nahi (fresh install), toh HTML ka default (checked) rehta hai.
  try {
    const storageKeys = STEP2_CHECKBOXES.map(c => c.storageKey);
    const stored = await chrome.storage.local.get(storageKeys);

    STEP2_CHECKBOXES.forEach(({ id, storageKey }) => {
      const chk = document.getElementById(id);
      if (!chk) return;
      const val = stored[storageKey];
      if (val !== undefined) {
        chk.checked = val === "1";
      }
      // Agar val undefined hai (storage mein nahi) toh HTML default (checked) rehne do
    });
  } catch (_) {
    // Non-fatal — checkbox state restore nahi hua, HTML default rehega
  }

  btn.addEventListener("click", async () => {
    try {
      const raw = input.value.trim();

      // Sirf whole numbers 0 se 100 tak
      if (!/^\d+$/.test(raw)) {
        alert("Sirf numbers allowed hain (0 to 100).");
        return;
      }

      const num = parseInt(raw, 10);

      if (num < 0 || num > 100) {
        alert("Number 0 se 100 ke beech hona chahiye.");
        return;
      }

      // Checkboxes ki values collect karo
      const checkboxData = {};
      STEP2_CHECKBOXES.forEach(({ id, storageKey }) => {
        const chk = document.getElementById(id);
        checkboxData[storageKey] = chk && chk.checked ? "1" : "0";
      });

      // Ek hi call mein sab save karo — atomic operation
      await chrome.storage.local.set({
        account_number: String(num),
        ...checkboxData,
        is_step2_done: "1"
      });

      btn.disabled   = true;
      input.disabled = true;

    } catch (err) {
      alert("Error Code : 02\n\n" + err.message);
    }
  });
}

export { renderStep2, isStep1Done, isStep2Done, STEP2_CHECKBOXES };
