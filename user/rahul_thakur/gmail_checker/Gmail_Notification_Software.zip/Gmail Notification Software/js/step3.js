// Step 3 Module — Fetch and Save Mail Count

/*
  ERROR CODES (is file ke):
  -8 → isStep3Done()   — chrome.storage.local.get fail (is_step3_done)
  04 → fetchAndSave()  — chrome.storage.local read fail (account_number)
  05 → fetchAndSave()  — fetch() network error (no internet, DNS fail, etc.)
  06 → fetchAndSave()  — HTTP response not ok (status code ke saath)
  07 → fetchAndSave()  — response.text() read fail
  08 → fetchAndSave()  — XML parse fail ya <fullcount> tag nahi mila
  09 → fetchAndSave()  — chrome.storage.local.set fail (counts save)
  10 → renderStep3()   — Unexpected/uncaught error in click handler
  11 → fetchAndSave()  — chrome.storage.local.set fail (is_step3_done save)
  12 → fetchAndSave()  — chrome.storage.local.set fail (is_setup_done save)
*/

// ── Helper — step2 done hai ya nahi ──────────────────────────

async function isStep2DoneForStep3() {
  try {
    const r = await chrome.storage.local.get("is_step2_done");
    return r["is_step2_done"] === "1";
  } catch (_) {
    return false;
  }
}

// ── Helper — step3 done hai ya nahi ──────────────────────────

async function isStep3Done() {
  try {
    const r = await chrome.storage.local.get("is_step3_done");
    return r["is_step3_done"] === "1";
  } catch (err) {
    alert("Error Code : -8\n\n" + err.message);
    return false;
  }
}

// ── Core fetch logic ──────────────────────────────────────────

async function fetchAndSave() {

  // Step 1: account_number padho
  let accountNumber;
  try {
    const r = await chrome.storage.local.get("account_number");
    accountNumber = r["account_number"];
    if (accountNumber === undefined) {
      throw new Error("account_number storage mein nahi mila. Pehle Step 1 aur Step 2 complete karo.");
    }
  } catch (err) {
    alert("Error Code : 04\n\n" + err.message);
    return false;
  }

  const url = `https://mail.google.com/mail/u/${accountNumber}/feed/atom`;

  // Step 2: HTTP request bhejo
  let response;
  try {
    response = await fetch(url, {
      method:      "GET",
      credentials: "include", // Gmail cookies bhejne ke liye
    });
  } catch (err) {
    alert(
      "Error Code : 05\n\n" +
      "Gmail server tak request nahi pahunchi.\n" +
      "Internet connection check karo ya dobara try karo.\n\n" +
      "Detail: " + err.message
    );
    return false;
  }

  // Step 3: HTTP status check
  if (!response.ok) {
    let hint = "";
    if      (response.status === 401) hint = "\nGmail mein login nahi ho, ya session expire ho gaya.";
    else if (response.status === 403) hint = "\nAccess denied. Account number galat ho sakta hai.";
    else if (response.status >= 500)  hint = "\nGmail server error. Thodi der baad try karo.";
    alert(
      "Error Code : 06\n\n" +
      "HTTP " + response.status + " — " + response.statusText +
      hint
    );
    return false;
  }

  // Step 4: Response body padho
  let xmlText;
  try {
    xmlText = await response.text();
  } catch (err) {
    alert("Error Code : 07\n\nResponse body read nahi hua.\n\n" + err.message);
    return false;
  }

  // Step 5: <fullcount> extract karo
  // Regex use karo — background worker ke saath consistent aur module script mein bhi reliable
  let count;
  try {
    const match = xmlText.match(/<fullcount>(\d+)<\/fullcount>/);
    if (!match) {
      throw new Error(
        "<fullcount> tag response mein nahi mila.\n" +
        "Shayad Gmail logged out ho ya feed format change ho gaya."
      );
    }
    count = match[1];
    if (!/^\d+$/.test(count)) {
      throw new Error("<fullcount> mein invalid value mili: \"" + count + "\"");
    }
  } catch (err) {
    alert("Error Code : 08\n\n" + err.message);
    return false;
  }

  // Step 6: Mail counts save karo
  try {
    await chrome.storage.local.set({
      old_mails_count: count,
      new_mails_count: count
    });
  } catch (err) {
    alert(
      "Error Code : 09\n\n" +
      "Mail count storage mein save nahi hua.\n\n" +
      "Detail: " + err.message
    );
    return false;
  }

  // Step 7: Step 3 completion flag save karo
  try {
    await chrome.storage.local.set({ is_step3_done: "1" });
  } catch (err) {
    alert(
      "Error Code : 11\n\n" +
      "Step 3 completion flag storage mein save nahi hua.\n\n" +
      "Detail: " + err.message
    );
    return false;
  }

  // Step 8: Setup done flag save karo — boolean true (background worker isko === true check karta hai)
  try {
    await chrome.storage.local.set({ is_setup_done: true });
  } catch (err) {
    alert(
      "Error Code : 12\n\n" +
      "Setup done flag storage mein save nahi hua.\n\n" +
      "Detail: " + err.message
    );
    return false;
  }

  return true; // success
}

// ── Render — button bind karo ─────────────────────────────────

function renderStep3() {
  const btn = document.getElementById("btn-fetch-save");
  if (!btn) return;

  btn.addEventListener("click", async () => {
    try {
      btn.disabled    = true;
      btn.textContent = "Fetching...";

      const success = await fetchAndSave();

      if (success) {
        btn.textContent = "✓ Saved!";
        btn.disabled    = true;
      } else {
        btn.textContent = "Save";
        btn.disabled    = !(await isStep2DoneForStep3());
      }
    } catch (err) {
      alert("Error Code : 10\n\nUnexpected error:\n\n" + err.message);
      btn.textContent = "Save";
      btn.disabled    = !(await isStep2DoneForStep3());
    }
  });
}

export { renderStep3, isStep2DoneForStep3, isStep3Done };
