// Background Service Worker — Independent Mail Count Monitor
// Yeh hamesha chalta rahega. Kabhi nahi rukta. Ziddi hai.

// Gate import — sabse pehle (badge_worker aur toast_worker ke liye zaruri)
importScripts("gate.js");

// Badge Worker import — parallel loop badge ke liye
importScripts("badge_worker.js");

// Toast Worker import — chrome.notifications toast ke liye
importScripts("toast_worker.js");

/*
  ERROR CODES (is file ke):
  13 → is_setup_done read fail         — chrome.storage.local error
  14 → account_number read fail        — chrome.storage.local error
  15 → new_mails_count read fail       — chrome.storage.local error
  16 → fetch() network error           — no internet, DNS fail, etc.
  17 → HTTP response not ok            — status code ke saath
  18 → response.text() read fail       — body parse nahi hua
  19 → XML parse fail                  — <fullcount> tag nahi mila
  20 → old_mails_count write fail      — chrome.storage.local error
  21 → new_mails_count write fail      — chrome.storage.local error
*/

const DELAY_MS = 1000;

// ── SW kill hone ke baad restart track karne ke liye ─────────
// Har SW restart par yeh false hoti hai — alarm isse check karta hai
let loopRunning = false;

// ── Helpers ───────────────────────────────────────────────────

function wait(ms) {
  return new Promise(res => setTimeout(res, ms));
}

// Error chrome.storage.local mein save karo
// Settings page ka live box isse display karega
async function setError(code, msg) {
  try {
    await chrome.storage.local.set({
      bg_last_error_code: String(code),
      bg_last_error_msg:  `[${code}] ${msg}`
    });
  } catch (_) {
    // Storage bhi fail hui — sirf console mein log karo
    console.error(`[BG ERR ${code}] ${msg}`);
  }
}

async function clearError() {
  try {
    await chrome.storage.local.set({
      bg_last_error_code: "",
      bg_last_error_msg:  ""
    });
  } catch (_) {}
}

// ── Main Loop ─────────────────────────────────────────────────
// while(true) — yeh loop sirf Chrome ke haath se rok sakta hai
// Alarm isko restart kar deta hai agar Chrome ne SW kill kiya

async function mainLoop() {
  loopRunning = true;

  while (true) {

    // ── Trial check — expired hone par loop silently wait karta hai ──
    if (!_v()) { await wait(60000); continue; }

    // ════════════════════════════════════════════════════════════
    // PHASE 1 — is_setup_done check
    // ════════════════════════════════════════════════════════════

    let isSetupDone;
    try {
      const r = await chrome.storage.local.get("is_setup_done");
      isSetupDone = r["is_setup_done"];
    } catch (err) {
      await setError(13, "is_setup_done read fail: " + err.message);
      await wait(DELAY_MS);
      continue; // Loop restart
    }

    if (isSetupDone !== true) {
      // Setup abhi baaqi hai — silently wait karo, koi error nahi
      await wait(DELAY_MS);
      continue; // Loop restart
    }

    // Setup done — aage badho
    await clearError();
    await wait(DELAY_MS);

    // ════════════════════════════════════════════════════════════
    // PHASE 2 — account_number padho
    // ════════════════════════════════════════════════════════════

    let accountNumber;
    try {
      const r = await chrome.storage.local.get("account_number");
      accountNumber = r["account_number"];
      if (accountNumber === undefined) {
        throw new Error("account_number storage mein nahi mila");
      }
    } catch (err) {
      await setError(14, err.message);
      await wait(DELAY_MS);
      continue; // Loop restart
    }

    // ════════════════════════════════════════════════════════════
    // PHASE 3 — new_mails_count padho
    // ════════════════════════════════════════════════════════════

    let currentNewMailsCount;
    try {
      const r = await chrome.storage.local.get("new_mails_count");
      currentNewMailsCount = r["new_mails_count"];
      if (currentNewMailsCount === undefined) {
        throw new Error("new_mails_count storage mein nahi mila");
      }
    } catch (err) {
      await setError(15, err.message);
      await wait(DELAY_MS);
      continue; // Loop restart
    }

    // ════════════════════════════════════════════════════════════
    // PHASE 4 — Gmail Atom feed fetch karo
    // ════════════════════════════════════════════════════════════

    const url = `https://mail.google.com/mail/u/${accountNumber}/feed/atom`;

    // Step 4a — HTTP request
    let response;
    try {
      response = await fetch(url, { method: "GET", credentials: "include" });
    } catch (err) {
      await setError(16, "Network error: " + err.message);
      await wait(DELAY_MS);
      continue; // Loop restart
    }

    // Step 4b — HTTP status check
    if (!response.ok) {
      let hint = "";
      if      (response.status === 401) hint = " — Login expire ya missing";
      else if (response.status === 403) hint = " — Access denied, account_number galat?";
      else if (response.status >= 500)  hint = " — Gmail server down";
      await setError(17, `HTTP ${response.status}${hint}`);
      await wait(DELAY_MS);
      continue; // Loop restart
    }

    // Step 4c — Response body padho
    let xmlText;
    try {
      xmlText = await response.text();
    } catch (err) {
      await setError(18, "Response body read fail: " + err.message);
      await wait(DELAY_MS);
      continue; // Loop restart
    }

    // Step 4d — <fullcount> extract karo
    // Note: Service Worker mein DOMParser nahi hota — regex use karo
    let fetchedCount;
    try {
      const match = xmlText.match(/<fullcount>(\d+)<\/fullcount>/);
      if (!match) {
        throw new Error("<fullcount> tag nahi mila. Gmail logged out ho sakta hai.");
      }
      fetchedCount = match[1]; // String, e.g. "5"
    } catch (err) {
      await setError(19, err.message);
      await wait(DELAY_MS);
      continue; // Loop restart
    }

    // ════════════════════════════════════════════════════════════
    // PHASE 5 — Compare: fetchedCount != currentNewMailsCount
    // ════════════════════════════════════════════════════════════

    if (String(fetchedCount) === String(currentNewMailsCount)) {
      // Koi change nahi — loop restart, check karte rehna
      await wait(DELAY_MS);
      continue; // Loop restart
    }

    // Count change hua hai — aage badho
    await wait(DELAY_MS);

    // ════════════════════════════════════════════════════════════
    // PHASE 6 — old_mails_count = new_mails_count
    // ════════════════════════════════════════════════════════════

    try {
      await chrome.storage.local.set({ old_mails_count: currentNewMailsCount });
    } catch (err) {
      await setError(20, "old_mails_count write fail: " + err.message);
      await wait(DELAY_MS);
      continue; // Loop restart
    }

    await wait(DELAY_MS);

    // ════════════════════════════════════════════════════════════
    // PHASE 7 — new_mails_count = fetchedCount
    // ════════════════════════════════════════════════════════════

    try {
      await chrome.storage.local.set({ new_mails_count: fetchedCount });
    } catch (err) {
      await setError(21, "new_mails_count write fail: " + err.message);
      await wait(DELAY_MS);
      continue; // Loop restart
    }

    await wait(DELAY_MS);
    // Loop restart — wapas Phase 1 se (is_setup_done check)
  }
}

// ── SW Lifecycle Hooks ────────────────────────────────────────

self.addEventListener("install", () => self.skipWaiting());

self.addEventListener("activate", (e) => e.waitUntil(clients.claim()));

// ── Keepalive Alarm ───────────────────────────────────────────
// MV3 Service Worker 30s idle hone par Chrome kill kar sakta hai.
// Alarm har minute fire hota hai — agar SW restart hua toh dono loops
// wapas shuru ho jaati hain.
// loopRunning / badgeLoopRunning SW restart par false ho jaate hain,
// isliye alarm correctly detect kar leta hai.

chrome.alarms.create("bg_keepalive", { periodInMinutes: 1 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "bg_keepalive") {
    if (!loopRunning)      mainLoop();
    if (!badgeLoopRunning) badgeLoop();
  }
});

// ── Dono Loops Shuru ─────────────────────────────────────────
mainLoop();
badgeLoop();
