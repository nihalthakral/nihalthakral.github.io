// Offscreen Document Script — Audio Playback
// toast_worker.js se PLAY_NOTIFICATION_SOUND message aata hai
// Audio bajao, khatam hone ke baad background ko message bhejo document close karne ke liye

// NOTE: chrome.offscreen API offscreen document ke andar AVAILABLE NAHI HOTI —
//       sirf Service Worker mein hoti hai. Isliye hum background ko
//       CLOSE_OFFSCREEN_DOCUMENT message bhejte hain — woh closeDocument() call karega.

/*
  ERROR CODES (is file ke):
  36 → offscreen.js — audio.play() fail (autoplay block ya decode error)
       Toast Worker ka "Toast Worker" section mein dikhega (toast_last_error_code)
*/

// ── Error Helper ─────────────────────────────────────────────
// offscreen.js mein chrome.storage seedha available hai.
// Toast Worker ke saath shared error keys use karte hain —
// settings.html ka "Toast Worker" section inhe display karta hai.

async function setOffscreenError(code, msg) {
  try {
    await chrome.storage.local.set({
      toast_last_error_code: String(code),
      toast_last_error_msg:  `[${code}] ${msg}`
    });
  } catch (_) {
    console.error(`[OFFSCREEN ERR ${code}] ${msg}`);
  }
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type !== "PLAY_NOTIFICATION_SOUND") return;

  const audio = new Audio(chrome.runtime.getURL("audio.mp3"));

  // Playback khatam — background ko close karne ka signal bhejo
  audio.onended = () => {
    chrome.runtime.sendMessage({ type: "CLOSE_OFFSCREEN_DOCUMENT" }).catch(() => {});
  };

  // Play fail hua — error code 36 save karo, phir close signal bhejo
  audio.play().catch(async (err) => {
    await setOffscreenError(36, "audio.play() fail: " + err.message);
    chrome.runtime.sendMessage({ type: "CLOSE_OFFSCREEN_DOCUMENT" }).catch(() => {});
  });
});
