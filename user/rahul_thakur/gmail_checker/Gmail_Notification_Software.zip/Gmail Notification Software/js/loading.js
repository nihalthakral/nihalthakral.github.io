// Loading Module — Gmail Smart Loader Content Script
// Gmail khulne aur navigate karne par loading overlay dikhata hai.
// Shadow DOM use karta hai — Gmail CSS se complete isolation.

/*
  STRATEGY: "Mutation Storm Settling"

  Loading  = DOM mutations zyada ho rahi hain
  Ready    = DOM ~800ms se quiet hai
  Navigate = URL ka hash badla (genuine navigation)
  Ignore   = URL nahi badla (Gmail ka background sync) ✓

  Future-proof kyunki:
  • MutationObserver = W3C standard (2012, permanent)
  • History API      = HTML5 standard (permanent)
  • Shadow DOM       = W3C standard (style isolation)
  • Gmail-specific kuch bhi nahi — zero fragile selectors

  ERROR CODES (is file ke):
  26 → buildOverlay()    — Shadow DOM / overlay DOM build fail
  27 → connectObserver() — MutationObserver setup fail
  28 → hookNavigation()  — Navigation event hooks setup fail
  29 → bootstrap         — Top-level init mein unexpected error
*/

(function () {
  'use strict';

  // ── CONFIG ─────────────────────────────────────────────────────────────────
  const C = {
    // DOM kitni der quiet rahe toh "loaded" maana jaaye
    SETTLE_INITIAL:    900,   // ms — pehli baar load hone pe
    SETTLE_NAV:        550,   // ms — SPA navigation ke baad

    // Overlay minimum kitna dikhe (flickering avoid karne ke liye)
    MIN_SHOW_INITIAL:  700,   // ms — initial load
    MIN_SHOW_NAV:      300,   // ms — navigation

    // Safety net: kitne time baad force hide karo
    SAFETY_MS:       15000,   // 15 seconds — last resort

    // Kitni baar settle check karo
    POLL_MS:            60,   // ms

    // Fade-out animation duration
    FADE_MS:           400,   // ms (CSS ke saath match karna)

    // Overlay — Gmail native white (frosted glass feel)
    BG:   'rgba(255, 255, 255, 0.85)',

    // Spinner — Gmail ka official blue (#1a73e8)
    BLUE: '#1a73e8',
  };

  // ── ERROR REPORTING ────────────────────────────────────────────────────────
  // Errors chrome.storage.local mein save karo.
  // Settings page ka "Loading Module" section live dikhata hai.

  function setError(code, msg) {
    try {
      chrome.storage.local.set({
        loading_last_error_code: String(code),
        loading_last_error_msg:  `[${code}] ${msg}`
      });
    } catch (_) {
      // Storage bhi fail — sirf console mein log karo
      console.error(`[LOADING ERR ${code}] ${msg}`);
    }
  }

  function clearError() {
    try {
      chrome.storage.local.set({
        loading_last_error_code: '',
        loading_last_error_msg:  ''
      });
    } catch (_) {}
  }

  // ── STATE ──────────────────────────────────────────────────────────────────
  let host        = null;   // Shadow DOM ka host element
  let shadow      = null;   // Shadow root
  let overlayEl   = null;   // Actual overlay div
  let mo          = null;   // MutationObserver instance

  let lastMutAt   = Date.now();  // Pichli mutation kab aayi
  let shownAt     = 0;           // Overlay kab dikhaya
  let isVisible   = false;       // Abhi dikha raha hai?
  let isInitial   = true;        // Pehla load hai?
  let pollTimer   = null;
  let safetyTimer = null;

  // ── SHADOW DOM CSS ─────────────────────────────────────────────────────────
  // Shadow DOM mein hone ki wajah se Gmail ka koi bhi CSS yahan nahi aayega
  // aur hamara CSS Gmail ko affect nahi karega — complete isolation
  const SHADOW_CSS = `
    *,
    *::before,
    *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    .overlay {
      position: fixed;
      inset: 0;
      background: ${C.BG};
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 2147483647;
      pointer-events: all;
      cursor: default;

      /* Smooth fade-out */
      opacity: 1;
      transition: opacity ${C.FADE_MS}ms cubic-bezier(0.4, 0, 0.2, 1);
    }

    .overlay.fade-out {
      opacity: 0;
      pointer-events: none;
    }

    /* ─── Gmail-style circular spinner ─── */
    .spinner {
      width: 36px;
      height: 36px;
      border-radius: 50%;

      /* Track ring */
      border: 3px solid rgba(26, 115, 232, 0.18);

      /* Active arc — Gmail blue */
      border-top-color: ${C.BLUE};

      animation: spin 0.85s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }
  `;

  // ── BUILD OVERLAY ──────────────────────────────────────────────────────────
  function buildOverlay() {
    try {
      host = document.createElement('div');
      host.id = '__gmail_smart_loader__';

      // Host ko fixed position karo — overlay shadow DOM mein handle karega visuals
      host.style.cssText = [
        'position: fixed',
        'top: 0',
        'left: 0',
        'width: 0',
        'height: 0',
        'z-index: 2147483647',
        'pointer-events: none',
        'margin: 0',
        'padding: 0',
      ].join(' !important; ') + ' !important;';

      // Shadow DOM attach karo — Gmail ka CSS yahan nahi pahunchega
      shadow = host.attachShadow({ mode: 'closed' });

      shadow.innerHTML = `
        <style>${SHADOW_CSS}</style>
        <div class="overlay" id="overlay">
          <div class="spinner" role="status" aria-label="Loading"></div>
        </div>
      `;

      overlayEl = shadow.getElementById('overlay');

      // document_start pe body nahi hoti, isliye documentElement pe prepend karo
      const target = document.documentElement || document.body;
      target.prepend(host);

      clearError(); // Overlay build hua — koi error nahi
    } catch (err) {
      setError(26, 'buildOverlay fail: ' + err.message);
    }
  }

  // ── SHOW / HIDE ────────────────────────────────────────────────────────────
  function showOverlay() {
    if (isVisible) return;

    isVisible = true;
    shownAt   = Date.now();
    lastMutAt = Date.now();  // Navigation ke baad reset

    if (!host) buildOverlay();
    if (overlayEl) overlayEl.classList.remove('fade-out');
  }

  function hideOverlay() {
    if (!isVisible) return;

    isVisible = false;
    clearTimeout(safetyTimer);
    if (overlayEl) overlayEl.classList.add('fade-out');

    // Fade animation ke baad initial flag clear karo
    setTimeout(() => {
      isInitial = false;
    }, C.FADE_MS);
  }

  // ── MUTATION OBSERVER ──────────────────────────────────────────────────────
  /*
   * Ye observer poore document ko watch karta hai.
   * Jab bhi koi DOM change hoti hai — lastMutAt update hoti hai.
   * Jab DOM quiet rehti hai SETTLE_*_MS tak — page "ready" hai.
   *
   * Gmail ka background email sync bhi DOM mutations karta hai,
   * lekin woh URL nahi badalta → hum overlay nahi dikhate → ignore ✓
   */
  function connectObserver() {
    try {
      if (mo) mo.disconnect();

      mo = new MutationObserver(() => {
        lastMutAt = Date.now();
      });

      const target = document.documentElement || document.body || document;
      mo.observe(target, {
        childList:     true,   // Elements add/remove
        subtree:       true,   // Poora DOM tree
        attributes:    true,   // Attribute changes (class, style, etc.)
        characterData: false,  // Text content skip — noise zyada, signal kam
      });
    } catch (err) {
      setError(27, 'connectObserver fail: ' + err.message);
    }
  }

  // ── SETTLE POLLER ──────────────────────────────────────────────────────────
  /*
   * Har POLL_MS milliseconds mein check karo:
   * Kya DOM kaafi time se quiet hai? Kya minimum show time ho gayi?
   * Agar dono yes → overlay hide karo.
   */
  function startPoller() {
    if (pollTimer) clearInterval(pollTimer);

    pollTimer = setInterval(() => {
      if (!isVisible) return;

      const now     = Date.now();
      const settle  = isInitial ? C.SETTLE_INITIAL : C.SETTLE_NAV;
      const minShow = isInitial ? C.MIN_SHOW_INITIAL : C.MIN_SHOW_NAV;

      const domQuietFor  = now - lastMutAt;
      const overlayShown = now - shownAt;

      if (domQuietFor >= settle && overlayShown >= minShow) {
        hideOverlay();
      }
    }, C.POLL_MS);
  }

  // ── NAVIGATION DETECTION ───────────────────────────────────────────────────
  /*
   * Hum sirf URL-changing events pe overlay show karte hain.
   *
   * Gmail ke background requests (email sync, notifications check)
   * URL nahi badate → ye handler kabhi trigger nahi hota → overlay
   * show nahi hota → user ko bina wajah loading nahi dikhta ✓
   *
   * Teen events:
   * 1. hashchange  — Gmail ka primary routing (#inbox, #sent, #inbox/msg_id)
   * 2. pushState   — Future-proofing ke liye (agar Gmail kabhi switch kare)
   * 3. popstate    — Browser back/forward button
   *
   * replaceState NAHI pakad rahe — Gmail use karta hai minor state ke liye
   */
  function onNavigation() {
    lastMutAt = Date.now();

    // Safety timer HAMESHA reset karo — rapid navigation bug fix
    clearTimeout(safetyTimer);
    safetyTimer = setTimeout(hideOverlay, C.SAFETY_MS);

    if (!isVisible) {
      showOverlay();
    }
    // Agar overlay already dikha raha hai:
    // lastMutAt update ho gaya → poller automatically wait karega ✓
  }

  function hookNavigation() {
    try {
      // ① hashchange — Gmail ka #hash based routing
      window.addEventListener('hashchange', onNavigation, /* capture */ true);

      // ② popstate — Back/Forward buttons
      window.addEventListener('popstate', onNavigation, /* capture */ true);

      // ③ history.pushState monkey-patch
      //    Native function preserve karke, URL change detect karo
      const _nativePush = history.pushState.bind(history);
      history.pushState = function (...args) {
        const urlBefore = location.href;
        _nativePush(...args);
        // Sirf tab trigger karo jab URL actually badli ho
        if (location.href !== urlBefore) {
          onNavigation();
        }
      };

      // Note: replaceState hook nahi kar rahe — intentional design decision
    } catch (err) {
      setError(28, 'hookNavigation fail: ' + err.message);
    }
  }

  // ── SAFETY NET ─────────────────────────────────────────────────────────────
  // Agar kisi wajah se DOM kabhi settle na ho (edge case),
  // 15 seconds baad force hide karo
  function armSafety() {
    clearTimeout(safetyTimer);
    safetyTimer = setTimeout(hideOverlay, C.SAFETY_MS);
  }

  // ── BOOTSTRAP ──────────────────────────────────────────────────────────────
  // run_at: "document_start" matlab Gmail ke kisi bhi JS se pehle chalega
  // is wajah se user ko blank white page nahi dikha — seedha spinner

  try {
    buildOverlay();    // Overlay DOM mein daalo
    showOverlay();     // Turant dikhao
    connectObserver(); // Mutations track karna shuru
    startPoller();     // Settling check loop start
    hookNavigation();  // URL changes intercept karo
    armSafety();       // Worst-case timer set karo

    // DOMContentLoaded pe observer dobara connect karo
    // (document_start pe <body> nahi hota — ab complete DOM available hai)
    document.addEventListener('DOMContentLoaded', () => {
      connectObserver();
    }, { once: true });

  } catch (err) {
    setError(29, 'Bootstrap fail: ' + err.message);
  }

})();
