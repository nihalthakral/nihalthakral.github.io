import { renderStep1 } from "./step1.js";
import { renderStep2, STEP2_CHECKBOXES } from "./step2.js";
import { renderStep3 } from "./step3.js";
import { renderResetButton } from "./reset.js";

/*
  FULL ERROR CODE REFERENCE
  ──────────────────────────────────────────────────────────────
  -8  → step3.js      — isStep3Done(): chrome.storage.local.get fail (is_step3_done)
  -7  → step1.js      — renderStep1() initial disable: btn.disabled fail
  -6  → settings.js   — Module init: renderX() calls fail on page load
  -5  → settings.js   — checkStepStates(): storage read ya DOM access fail
  -4  → step2.js      — isStep2Done(): chrome.storage.local.get fail
  -3  → step2.js      — isStep1Done(): chrome.storage.local.get fail
  -2  → step1.js      — isAlreadySetup(): chrome.storage.local.get fail
  -1  → settings.js   — Live boxes update: storage read ya DOM fail
   0  → reset.js      — Reset button: chrome.storage.local.remove ya reload fail
  01  → step1.js      — Step 1 button click: setupKeys() fail
  02  → step2.js      — Step 2 save button: chrome.storage.local.set ya parse fail
  03  → popup.js      — Settings button: chrome.tabs.create ya runtime.getURL fail
  04  → step3.js      — fetchAndSave(): chrome.storage.local read fail (account_number)
  05  → step3.js      — fetchAndSave(): fetch() network error
  06  → step3.js      — fetchAndSave(): HTTP response not ok (status code ke saath)
  07  → step3.js      — fetchAndSave(): response.text() read fail
  08  → step3.js      — fetchAndSave(): XML parse fail ya <fullcount> nahi mila
  09  → step3.js      — fetchAndSave(): chrome.storage.local.set fail (counts save)
  10  → step3.js      — renderStep3(): unexpected/uncaught error in click handler
  11  → step3.js      — fetchAndSave(): chrome.storage.local.set fail (is_step3_done)
  12  → step3.js      — fetchAndSave(): chrome.storage.local.set fail (is_setup_done)
  13  → background.js — is_setup_done read fail (chrome.storage.local error)
  14  → background.js — account_number read fail (chrome.storage.local error)
  15  → background.js — new_mails_count read fail (chrome.storage.local error)
  16  → background.js — fetch() network error
  17  → background.js — HTTP response not ok
  18  → background.js — response.text() read fail
  19  → background.js — XML parse fail ya <fullcount> tag nahi mila
  20  → background.js — old_mails_count write fail (chrome.storage.local error)
  21  → background.js — new_mails_count write fail (chrome.storage.local error)
  22  → badge_worker.js — storage read fail (old_mails_count / new_mails_count /
                          want_extension_badge / want_toast_notification)
  23  → badge_worker.js — chrome.action.setBadgeText fail (badge lagane waqt)
  24  → badge_worker.js — chrome.action.setBadgeBackgroundColor fail
  25  → badge_worker.js — chrome.action.setBadgeText fail (badge hatane waqt)
  26  → loading.js    — buildOverlay(): Shadow DOM ya overlay DOM build fail
  27  → loading.js    — connectObserver(): MutationObserver setup fail
  28  → loading.js    — hookNavigation(): Navigation event hooks setup fail
  29  → loading.js    — bootstrap: Top-level init mein unexpected error
  30  → popup.js      — Open Gmail button: chrome.storage.local.get fail (account_number)
  31  → popup.js      — Open Gmail button: chrome.tabs.create fail
  32  → toast_worker.js — chrome.notifications.create fail
  33  → toast_worker.js — notifications.onClicked: chrome.tabs.create fail
  34  → toast_worker.js — offscreen document create ya audio play fail
  ──────────────────────────────────────────────────────────────
*/

// ── Live Boxes — sabhi keys ───────────────────────────────────

const KEYS = [
  { storageKey: "is_setup_done",            elementId: "val-is-setup-done"             },
  { storageKey: "old_mails_count",          elementId: "val-old-mails-count"           },
  { storageKey: "new_mails_count",          elementId: "val-new-mails-count"           },
  { storageKey: "account_number",           elementId: "val-account-number"            },
  { storageKey: "is_step2_done",            elementId: "val-is-step2-done"             },
  { storageKey: "is_step3_done",            elementId: "val-is-step3-done"             },
  { storageKey: "want_toast_notification",  elementId: "val-want-toast-notification"   },
  { storageKey: "want_extension_badge",     elementId: "val-want-extension-badge"      },
  { storageKey: "bg_last_error_code",       elementId: "val-bg-error-code"             },
  { storageKey: "bg_last_error_msg",        elementId: "val-bg-error-msg"              },
  { storageKey: "badge_last_error_code",    elementId: "val-badge-error-code"          },
  { storageKey: "badge_last_error_msg",     elementId: "val-badge-error-msg"           },
  { storageKey: "toast_last_error_code",    elementId: "val-toast-error-code"          },
  { storageKey: "toast_last_error_msg",     elementId: "val-toast-error-msg"           },
  { storageKey: "loading_last_error_code",  elementId: "val-loading-error-code"        },
  { storageKey: "loading_last_error_msg",   elementId: "val-loading-error-msg"         }
];

async function updateLiveBoxes() {
  try {
    const storageKeys = KEYS.map(k => k.storageKey);
    const result = await chrome.storage.local.get(storageKeys);

    KEYS.forEach(({ storageKey, elementId }) => {
      const el = document.getElementById(elementId);
      if (!el) return;

      const value = result[storageKey];

      if (value === undefined || value === null || value === "") {
        el.textContent = "-";
        el.classList.add("empty");
        el.classList.remove("has-error");
      } else {
        el.textContent = String(value);
        el.classList.remove("empty");

        // Error code hone par red highlight
        if (
          storageKey === "bg_last_error_code"      ||
          storageKey === "bg_last_error_msg"       ||
          storageKey === "badge_last_error_code"   ||
          storageKey === "badge_last_error_msg"    ||
          storageKey === "toast_last_error_code"   ||
          storageKey === "toast_last_error_msg"    ||
          storageKey === "loading_last_error_code" ||
          storageKey === "loading_last_error_msg"
        ) {
          el.classList.add("has-error");
        }
      }
    });
  } catch (err) {
    alert("Error Code : -1\n\n" + err.message);
  }
}

// ── Step States — disable/enable ──────────────────────────────

async function checkStepStates() {
  try {
    // Ek hi storage call mein sab padho — efficient
    const r = await chrome.storage.local.get([
      "is_setup_done",
      "is_step2_done",
      "is_step3_done"
    ]);

    const step1Done = r["is_setup_done"] !== undefined; // Key exist = step 1 hua tha
    const step2Done = r["is_step2_done"] === "1";
    const step3Done = r["is_step3_done"] === "1";

    const step1Btn   = document.getElementById("btn-setup-keys");
    const step2Btn   = document.getElementById("btn-save-account");
    const step2Input = document.getElementById("input-account-number");
    const step3Btn   = document.getElementById("btn-fetch-save");

    if (step1Btn) {
      step1Btn.disabled = step1Done;
    }

    if (step2Btn && step2Input) {
      const disable2    = !step1Done || step2Done;
      step2Btn.disabled   = disable2;
      step2Input.disabled = disable2;
    }

    STEP2_CHECKBOXES.forEach(({ id }) => {
      const chk = document.getElementById(id);
      if (chk) chk.disabled = !step1Done || step2Done;
    });

    if (step3Btn) {
      if (step3Done) {
        step3Btn.disabled = true;
      } else if (step3Btn.textContent !== "Fetching...") {
        step3Btn.disabled = !step2Done;
      }
    }

  } catch (err) {
    alert("Error Code : -5\n\n" + err.message);
  }
}

// ── Developer View — toggle on button click, hide on outside click ─

function initDevView() {
  const btn  = document.getElementById("btn-dev-view");
  const card = document.getElementById("dev-card");
  if (!btn || !card) return;

  // Button click: toggle visibility
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    card.classList.toggle("visible");
  });

  // Card ke andar click: bubble rokho taaki card band na ho
  card.addEventListener("click", (e) => {
    e.stopPropagation();
  });

  // Kahi bhi aur click: card band karo
  document.addEventListener("click", () => {
    card.classList.remove("visible");
  });
}

// ── Polling — async-safe (setInterval nahi, setTimeout chain) ─
// setInterval ke saath async functions stack ho sakte hain.
// Yeh pattern ensure karta hai ki ek tick complete hone ke baad hi agli shuru ho.

async function startLiveUpdates() {
  async function tick() {
    await updateLiveBoxes();
    await checkStepStates();
    setTimeout(tick, 1000);
  }
  tick();
}

// ── Init ──────────────────────────────────────────────────────

async function init() {

  // ── Trial Check — sabse pehle ────────────────────────────────
  // _v() gate.js se aata hai (global script) — false = trial khatam
  if (typeof _v === "function" && !_v()) {
    const overlay = document.getElementById("expired-overlay");
    if (overlay) overlay.style.display = "flex";

    const contactBtn = document.getElementById("btn-contact");
    if (contactBtn) {
      contactBtn.addEventListener("click", () => {
        try {
          chrome.tabs.create({
            url: "https://mail.google.com/mail/?view=cm&fs=1&to=nihalthakral.trader@gmail.com"
          });
        } catch (_) {}
      });
    }

    return; // Settings page ki baaki functionality bilkul band
  }

  // ── Normal Init ──────────────────────────────────────────────

  try {
    initDevView();
    renderResetButton();
    await renderStep1();  // Async — initial button state check karta hai
    await renderStep2();  // Async — storage se checkbox state restore karta hai
    renderStep3();        // Sync — sirf listener attach karta hai
    startLiveUpdates();
  } catch (err) {
    alert("Error Code : -6\n\n" + err.message);
  }
}

init();
