const toggle = document.getElementById('toggle');
const statusText = document.getElementById('statusText');
const toggleLabel = document.getElementById('toggleLabel');
const switchLabel = document.getElementById('switchLabel');

// Free Trial expiry check (config.js popup.js se pehle load hota hai - popup.html mein)
const expired = typeof isExtensionExpired === 'function' ? isExtensionExpired() : false;

if (expired) {
  // Trial expire ho chuka hai - toggle switch hata do, aur message dikhao.
  // Storage mein bhi enabled: false likh do, taaki sab jagah consistent rahe.
  chrome.storage.sync.set({ enabled: false });

  switchLabel.style.display = 'none';
  toggleLabel.style.display = 'none';
  statusText.textContent = 'Free Trial Ends';
  statusText.className = 'status-text expired';
} else {
  // Load saved state (default: ON)
  chrome.storage.sync.get({ enabled: true }, (data) => {
    toggle.checked = data.enabled;
    updateStatus(data.enabled);
  });

  // On toggle change → save & update UI
  toggle.addEventListener('change', () => {
    const enabled = toggle.checked;
    chrome.storage.sync.set({ enabled });
    updateStatus(enabled);
  });
}

function updateStatus(enabled) {
  if (enabled) {
    statusText.textContent = 'ON — ads hidden';
    statusText.className = 'status-text on';
  } else {
    statusText.textContent = 'OFF — ads not hidden';
    statusText.className = 'status-text off';
  }
}
