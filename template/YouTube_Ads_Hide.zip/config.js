// ============================================================
// CONFIG — Free Trial Expiry Date
// ============================================================
// Yahan apni expiry date set karo (format hamesha: "YYYY-MM-DD")
// Example: "2026-12-31" matlab 31 December 2026 ko expire hoga.
//
// Jis din system date isse equal ya isse aage chali jaayegi,
// extension permanently OFF ho jaayega — mute, blur, overlay,
// kuch bhi kaam nahi karega, chahe storage mein "enabled: true"
// hi pada ho. Yeh check content.js aur popup.js dono mein
// independently hota hai, sirf storage par depend nahi karta.
// ============================================================

const EXPIRY_DATE = "2007-10-14"; // <-- ISKO APNI MARZI SE BADLO

function isExtensionExpired() {
  const now = new Date();
  const todayStr =
    now.getFullYear() + "-" +
    String(now.getMonth() + 1).padStart(2, "0") + "-" +
    String(now.getDate()).padStart(2, "0");

  // YYYY-MM-DD format hone ki wajah se plain string comparison
  // hi date comparison ka kaam kar deta hai — koi timezone bug nahi.
  return todayStr >= EXPIRY_DATE;
}
