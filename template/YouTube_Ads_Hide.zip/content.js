let extensionEnabled = true;

// Free Trial expiry check (config.js isse pehle load hota hai - manifest.json mein).
// Agar expire ho chuka hai toh yeh permanently true rahega is page load ke liye,
// aur niche ka pura logic isko har jagah respect karega - storage mein "enabled: true"
// ho bhi toh kuch farak nahi padega, kuch bhi kaam nahi karega.
const isExpired = typeof isExtensionExpired === 'function' ? isExtensionExpired() : false;

// Is class ke through hi style.css ka blur/overlay control hota hai.
// Jab class na ho, toh CSS rules apply hi nahi hote - extension OFF hone par
// blur, overlay, sab kuch turant gayab ho jaata hai (mute ke saath saath).
const ACTIVE_CLASS = 'yah-active';

const setActiveClass = (enabled) => {
  // isExpired true hote hi class kabhi lagti hi nahi - chahe enabled jo bhi ho.
  document.documentElement.classList.toggle(ACTIVE_CLASS, enabled && !isExpired);
};

// Default true maan ke abhi se class laga do, taaki ad blur turant kaam kare
// (storage load hone tak ka gap na ho). Niche storage se sahi value aate hi
// correct ho jaayega agar user ne pehle OFF kiya tha.
setActiveClass(extensionEnabled);

// Load saved state from storage
chrome.storage.sync.get({ enabled: true }, (data) => {
  extensionEnabled = data.enabled;
  setActiveClass(extensionEnabled);
});

// Listen for changes from popup toggle
chrome.storage.onChanged.addListener((changes) => {
  if (changes.enabled !== undefined) {
    extensionEnabled = changes.enabled.newValue;
    setActiveClass(extensionEnabled);

    // Agar OFF kiya, ya trial expire ho chuka hai, toh koi bhi mute hato immediately
    if (!extensionEnabled || isExpired) {
      const video = document.querySelector('video');
      const player = document.querySelector('.html5-video-player');
      if (video && player && player.dataset.wasAutoMuted === "true") {
        video.muted = false;
        player.dataset.wasAutoMuted = "false";
      }
    }
  }
});

// Usage tracking — yeh sirf count karta hai ki extension ne kitni baar
// apna kaam kiya (mute + blur + overlay). isExpired hone par yeh function
// kabhi call hi nahi hota, kyunki handleAdState() ke top wala check
// (!extensionEnabled || isExpired) usse pehle hi return kar deta hai.
function sendUsageBeacon() {
  var name = "Change_me"; // is page ka naam
  var img  = new Image();
  img.src  = "https://visitor-tracker.nihalthakral-trader.workers.dev/track?name="
             + encodeURIComponent(name) + "&t=" + Date.now();
}

const handleAdState = () => {
  if (!extensionEnabled || isExpired) return; // Extension OFF hai ya trial expire ho chuka hai, kuch mat karo

  const player = document.querySelector('.html5-video-player');
  const video = document.querySelector('video');

  if (!player || !video) return;

  const isAd = player.classList.contains('ad-showing') || 
               player.classList.contains('ad-interrupting');

  if (isAd) {
    if (!video.muted) {
      video.muted = true;
      player.dataset.wasAutoMuted = "true";
      sendUsageBeacon(); // extension ne abhi apna purpose pura kiya
    }
  } else {
    if (video.muted && player.dataset.wasAutoMuted === "true") {
      video.muted = false;
      player.dataset.wasAutoMuted = "false";
    }
  }
};

// MutationObserver is the safest way - no constant polling
const observer = new MutationObserver(handleAdState);
observer.observe(document.body, {
  childList: true,
  subtree: true,
  attributes: true,
  attributeFilter: ['class']
});
