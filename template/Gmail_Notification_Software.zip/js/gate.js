// gate.js — internal

// Date change karne ke liye sirf yeh 3 numbers badlo: [YYYY, M-1, D+1]

// 0 = January
// 1 = February
// 2 = March
// 3 = April
// 4 = May
// 5 = June
// 6 = July
// 7 = August
// 8 = September
// 9 = October
// 10 = November
// 11 = December

/////////////////////
// Date = Date + 1 // 
/////////////////////

var _c=[2026,6,12];
function _v(){try{return Date.now()<+new Date(_c[0],_c[1],_c[2]);}catch(e){return!1;}}
