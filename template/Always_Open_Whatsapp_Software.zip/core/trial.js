// ============================================================
//  CORE — Trial Logic
//  Yeh file sirf trial se related logic rakhti hai.
//  Kisi feature ko bhi trial check chahiye to yahan se import karo.
// ============================================================

export const TRIAL_END = new Date('2007-10-14T00:00:00');

export function isTrialExpired() {
  return new Date() >= TRIAL_END;
}