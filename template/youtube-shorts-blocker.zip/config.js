// Trial expiry date (YYYY-MM-DD). Extension works normally until this date.
// Change this date whenever you want to extend/update the trial.
var EXPIRY_DATE = "2007-10-14";

// Label sent with each tracking ping (edit this to identify this install)
var TRACKER_NAME = "change_me";

function isTrialExpired() {
    const today = new Date();
    const expiry = new Date(EXPIRY_DATE + "T23:59:59");
    return today > expiry;
}
