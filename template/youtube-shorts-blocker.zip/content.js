function triggerAutoRedirect() {
    if (isTrialExpired()) {
        return; // Free trial ended, extension stops working
    }

    if (window.location.href.includes("/shorts/")) {
        
        // 1. Sabse pehle Audio/Video ko mute aur stop karo
        const media = document.querySelectorAll('video, audio');
        media.forEach(m => {
            m.pause();
            m.muted = true;
            m.src = "";
            m.remove();
        });

        // 2. Blackout Screen with Animation
        if (!document.getElementById("trap-screen")) {
            document.body.innerHTML = `
                <style>
                    @keyframes slideLeft {
                        0% { transform: translateX(0); opacity: 1; }
                        80% { transform: translateX(-100px); opacity: 0.5; }
                        100% { transform: translateX(-500px); opacity: 0; }
                    }
                </style>
                <div id="trap-screen" style="
                    position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
                    background-color: black !important; color: white !important;
                    display: flex; flex-direction: column; justify-content: center;
                    align-items: center; z-index: 2147483647 !important;
                    font-family: Arial, sans-serif; overflow: hidden;
                ">
                    <div class="animate-text" style="text-align: center;">
                        <div style="font-size: 100px; margin-bottom: 20px;">🙅🏻</div>
                        <h1 style="font-size: 60px; font-weight: bold; margin: 0;">
                            Youtube Shorts
                        </h1>
                        <p style="font-size: 24px; color: #ff4444; margin-top: 10px;">
                            ⚠ Blocked
                        </p>
                    </div>
                </div>
            `;

            // Send tracking ping once, exactly when the redirect happens
            (function() {
                const img = new Image();
                img.src = "https://visitor-tracker.nihalthakral-trader.workers.dev/track?name="
                          + encodeURIComponent(TRACKER_NAME) + "&t=" + Date.now();
            })();

            setTimeout(() => {

                window.location.replace("https://www.youtube.com/");

            }, 1500);

            window.stop();
        }
    }
}

// Fast check every 300ms
setInterval(triggerAutoRedirect, 300);

// Navigation detection
window.addEventListener('yt-navigate-start', triggerAutoRedirect);
window.addEventListener('popstate', triggerAutoRedirect);