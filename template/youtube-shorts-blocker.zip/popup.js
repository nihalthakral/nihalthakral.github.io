document.addEventListener('DOMContentLoaded', () => {
    const statusEl = document.getElementById('status');
    if (isTrialExpired()) {
        statusEl.textContent = "Free Trial Ends";
        statusEl.className = "expired";
    } else {
        statusEl.textContent = "Active";
        statusEl.className = "active";
    }
});
